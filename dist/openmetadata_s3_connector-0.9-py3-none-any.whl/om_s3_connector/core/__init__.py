"""
Core components of the S3 Connector.

This module contains the main connector logic, configuration, and client classes.
"""

from .s3_connector import S3Source
from .connector import S3Connector
from .config import S3ConnectorConfig, S3ConnectionConfig, S3SecurityConfig
from .security import S3SecurityManager

__all__ = [
    "S3Source",
    "S3Connector",
    "S3ConnectorConfig",
    "S3ConnectionConfig", 
    "S3SecurityConfig",
    "S3SecurityManager"
]
